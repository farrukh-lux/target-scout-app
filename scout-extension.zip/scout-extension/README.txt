SCOUT FOR TARGET - Chrome extension
===================================

What it does
------------
When your Scout dashboard opens a Target search tab (the "Track keyword"
button or a keyword page's "Snapshot on Target" button), this extension
captures the top ~100 rankings automatically, sends them straight into the
dashboard, and closes the tab. No bookmark click, no paste.

You can also click the extension's icon on any Target search page you
opened yourself to capture that keyword manually.

Install (one time, ~2 minutes)
------------------------------
1. Unzip this folder somewhere permanent (e.g. Documents\scout-extension).
   Don't delete it later - Chrome loads the extension from this folder.
2. Open Chrome and go to:  chrome://extensions
3. Turn ON "Developer mode" (toggle in the top-right corner).
4. Click "Load unpacked" and choose the unzipped scout-extension folder.
5. Done. "Scout for Target" now appears in your extensions list.

Daily use
---------
In the dashboard: type a keyword, press Enter (or click "Track keyword").
The Target tab opens, captures itself, the results appear in your
dashboard, and the tab closes. That is the whole flow.

Notes
-----
- The old Scout bookmark still works and is a good backup; the extension
  ignores pages where the bookmark flow is being used manually.
- If Chrome shows "Developer mode extensions" warnings on startup, that is
  normal for unpacked extensions - click keep.
- The extension only runs on target.com search pages and sends data only
  to the dashboard tab that opened them (plus your clipboard as backup).
