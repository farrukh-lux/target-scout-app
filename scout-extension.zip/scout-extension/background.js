// Clicking the extension icon on a Target search page triggers a manual capture.
chrome.action.onClicked.addListener((tab) => {
  if (tab && tab.id) {
    chrome.tabs.sendMessage(tab.id, { scoutRun: true }).catch(() => {});
  }
});
