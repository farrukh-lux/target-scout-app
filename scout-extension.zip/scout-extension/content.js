// Scout for Target — content script.
// Auto-runs on search tabs opened by the Scout dashboard (&scout=auto),
// or manually when you click the extension icon on any Target search page.
(function () {
  "use strict";
  if (window.__scoutExtActive) return;
  window.__scoutExtActive = true;

  var q = new URLSearchParams(location.search);
  var TARGETN = 100, MAXPAGES = 5;

  /* ---------------- capture helpers (same logic as the Scout bookmark) ---------------- */
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function currentKeyword() {
    var kw = q.get("searchTerm") || q.get("q") || "";
    if (!kw && location.pathname.indexOf("/s/") === 0) {
      kw = decodeURIComponent(location.pathname.slice(3).split("/")[0]).replace(/-/g, " ");
    }
    return (kw || "").trim();
  }

  function mapItem(it, pos) {
    var st = (it.ratings_and_reviews && it.ratings_and_reviews.statistics &&
              it.ratings_and_reviews.statistics.rating) || {};
    return {
      position: pos,
      tcin: String(it.tcin || (it.item && it.item.tcin) || ""),
      title: (it.item && it.item.product_description && it.item.product_description.title) || it.title || "",
      brand: (it.item && it.item.primary_brand && it.item.primary_brand.name) || "",
      price: (it.price && (it.price.current_retail != null ? it.price.current_retail : it.price.current_retail_min)),
      rating: (st.average != null ? st.average : null),
      reviews: (st.count != null ? st.count : null),
      sponsored: !!(it.sponsored_ad || (it.item && it.item.sponsored_ad) || it.sponsored)
    };
  }

  function findProducts(o, d) {
    if (!o || d > 20) return null;
    if (typeof o === "string") {
      if (o.length > 1000 && o.indexOf("tcin") > -1) {
        try { return findProducts(JSON.parse(o), d + 1); } catch (e) {}
      }
      return null;
    }
    if (Array.isArray(o)) {
      if (o.length && o[0] && (o[0].tcin || (o[0].item && o[0].item.tcin))) return o;
      for (var i = 0; i < o.length; i++) { var f = findProducts(o[i], d + 1); if (f) return f; }
      return null;
    }
    if (typeof o === "object") {
      if (o.search && o.search.products && o.search.products.length) return o.search.products;
      var ks; try { ks = Object.getOwnPropertyNames(o); } catch (e) { ks = []; }
      for (var k = 0; k < ks.length; k++) {
        try { var f2 = findProducts(o[ks[k]], d + 1); if (f2) return f2; } catch (e) {}
      }
    }
    return null;
  }

  function scanEmbedded(root) {
    var scr = root.querySelectorAll("script"), emb = null;
    for (var i = 0; i < scr.length && !emb; i++) {
      var txt = scr[i].textContent || "";
      if (txt.length > 5000 && txt.indexOf("tcin") > -1 && txt.indexOf("{") > -1) {
        var a = txt.indexOf("{"), b = txt.lastIndexOf("}");
        if (a > -1 && b > a) {
          try { emb = findProducts(JSON.parse(txt.slice(a, b + 1)), 0); } catch (e) {}
        }
      }
    }
    return emb;
  }

  function readCard(cardEl, lk, m, pos) {
    var body = cardEl.textContent || "";
    var im = lk.querySelector("img") || cardEl.querySelector("img");
    var ttl = "";
    try {
      var tl = cardEl.querySelectorAll('a[href*="/A-' + m[1] + '"]');
      for (var ti = 0; ti < tl.length; ti++) {
        var tx = (tl[ti].textContent || "").trim().replace(/\s+/g, " ");
        if (tx.length >= 10 && tx.indexOf("$") === -1 && tx.length > ttl.length) ttl = tx;
      }
    } catch (e) {}
    if (!ttl) {
      var hd = cardEl.querySelector('[data-test*="itle"], h2, h3, h4');
      if (hd) ttl = (hd.textContent || "").trim().replace(/\s+/g, " ");
    }
    if (!ttl || ttl.length < 10) {
      var cut = body.indexOf("$");
      if (cut > 10) {
        var pre = body.slice(0, cut).replace(/\s+/g, " ").replace(/^\s*sponsored\s*/i, "").trim();
        if (pre.length >= 10) ttl = pre;
      }
    }
    if (!ttl) ttl = (lk.getAttribute("aria-label") || (im && im.alt) || lk.textContent || "")
      .trim().replace(/\s+/g, " ");
    ttl = ttl.slice(0, 120);
    if (!ttl) ttl = "Product " + m[1];
    var pm = body.match(/\$([\d,]+(?:\.\d+)?)/);
    var ra = null, rv = null;
    var m1 = body.match(/([\d.]+)\s*out of 5/); if (m1) ra = parseFloat(m1[1]);
    var m2 = body.match(/([\d,]+)\s*(?:ratings|reviews)/i); if (m2) rv = parseInt(m2[1].replace(/,/g, ""), 10);
    if (rv == null) {
      var rl = cardEl.querySelector('[aria-label*="out of 5"]');
      var lab = rl ? (rl.getAttribute("aria-label") || "") : "";
      var m3 = lab.match(/with\s+([\d,]+)/i) || lab.match(/([\d,]+)\s*(?:ratings?|reviews?)/i);
      if (m3) rv = parseInt(m3[1].replace(/,/g, ""), 10);
    }
    if (rv == null) {
      var m4 = body.match(/\((\d[\d,]*)\)/);
      if (m4) rv = parseInt(m4[1].replace(/,/g, ""), 10);
    }
    var bl = cardEl.querySelector('a[href*="/b/"]');
    return {
      position: pos, tcin: m[1], title: ttl,
      brand: bl ? (bl.textContent || "").trim().slice(0, 60) : "",
      price: pm ? parseFloat(pm[1].replace(/,/g, "")) : null,
      rating: ra, reviews: rv,
      sponsored: /\bsponsored\b/i.test(body)
    };
  }

  function scanGrid(root, off) {
    var out = [];
    var all = root.querySelectorAll('a[href*="/A-"]');
    var seenG = [], gCount = [];
    function gridFor(a) {
      var el = a;
      for (var i = 0; i < 10 && el.parentElement; i++) {
        var par = el.parentElement, cnt = 0, ch = par.children;
        for (var c = 0; c < ch.length; c++) {
          if (ch[c].querySelector && ch[c].querySelector('a[href*="/A-"]')) cnt++;
        }
        if (cnt >= 8) return par;
        el = par;
      }
      return null;
    }
    for (var A = 0; A < all.length; A++) {
      var g = gridFor(all[A]); if (!g) continue;
      var gi = seenG.indexOf(g);
      if (gi < 0) { seenG.push(g); gCount.push(1); } else gCount[gi]++;
    }
    var best = null, bestN = 0;
    for (var G = 0; G < seenG.length; G++) { if (gCount[G] > bestN) { bestN = gCount[G]; best = seenG[G]; } }
    var seenL = {};
    if (best) {
      var ch2 = best.children;
      for (var C = 0; C < ch2.length; C++) {
        var lk2 = ch2[C].querySelector('a[href*="/A-"]'); if (!lk2) continue;
        var mm = (lk2.getAttribute("href") || lk2.href || "").match(/\/A-(\d+)/);
        if (!mm || seenL[mm[1]]) continue;
        seenL[mm[1]] = 1;
        out.push(readCard(ch2[C], lk2, mm, off + out.length + 1));
      }
    }
    if (!out.length) {
      for (var L = 0; L < all.length && out.length < 48; L++) {
        var lk = all[L];
        var m = (lk.getAttribute("href") || lk.href || "").match(/\/A-(\d+)/);
        if (!m || seenL[m[1]]) continue;
        seenL[m[1]] = 1;
        var card = lk;
        for (var up = 0; up < 7 && card.parentElement; up++) {
          card = card.parentElement;
          var bt = card.textContent || "";
          if (bt.indexOf("$") > -1 && bt.length < 2500) break;
        }
        out.push(readCard(card, lk, m, off + out.length + 1));
      }
    }
    return out;
  }

  function totalOf(root) {
    var trm = ((root.body && root.body.textContent) || "").match(/([\d,]+)(\s*\+)?\s*results/i);
    if (!trm) return null;
    return { num: parseInt(trm[1].replace(/,/g, ""), 10), txt: trm[1] + (trm[2] ? "+" : "") };
  }

  function capturePage(root, off) {
    var emb = scanEmbedded(root);
    if (emb && emb.length) {
      var out = [];
      for (var i = 0; i < emb.length; i++) out.push(mapItem(emb[i], off + i + 1));
      return { items: out };
    }
    return { items: scanGrid(root, off) };
  }

  function loadPage(kw, off) {
    return new Promise(function (res) {
      var f = document.createElement("iframe");
      f.style.cssText = "position:fixed;left:-9999px;top:0;width:1200px;height:900px;visibility:hidden;";
      var done = false, t0 = Date.now();
      function finish(items, tot) {
        if (done) return; done = true;
        try { f.parentNode && f.parentNode.removeChild(f); } catch (e) {}
        res({ items: items, tot: tot });
      }
      function poll() {
        if (done) return;
        var d = null;
        try { d = f.contentDocument; } catch (e) {}
        if (d && d.readyState !== "loading") {
          try {
            var r = capturePage(d, off);
            if (r.items.length) return finish(r.items, totalOf(d));
          } catch (e) {}
        }
        if (Date.now() - t0 > 14000) return finish([], null);
        setTimeout(poll, 500);
      }
      f.onload = function () { setTimeout(poll, 700); };
      f.src = "/s?searchTerm=" + encodeURIComponent(kw) + "&Nao=" + off;
      (document.body || document.documentElement).appendChild(f);
      setTimeout(poll, 1800);
    });
  }

  /* ---------------- overlay ---------------- */
  var ov = null;
  function say(t) {
    if (!ov) {
      ov = document.createElement("div");
      ov.style.cssText = "position:fixed;top:16px;right:16px;z-index:2147483647;background:#1a1c20;color:#fff;" +
        "font:600 13px/1.5 Arial,sans-serif;padding:12px 16px;border-radius:10px;max-width:300px;" +
        "box-shadow:0 6px 24px rgba(0,0,0,.4)";
      (document.body || document.documentElement).appendChild(ov);
    }
    ov.textContent = "Scout: " + t;
  }
  function clearOverlay(delayMs) {
    setTimeout(function () {
      try { ov && ov.parentNode && ov.parentNode.removeChild(ov); } catch (e) {}
      ov = null;
    }, delayMs || 0);
  }

  /* ---------------- capture + delivery ---------------- */
  async function captureKeyword(kw) {
    var results = [], pages = 0, tres = null;
    var curOff = parseInt(q.get("Nao") || "0", 10);
    if (isNaN(curOff) || curOff < 0) curOff = 0;
    var cur = currentKeyword();
    if (cur && kw.toLowerCase() === cur.toLowerCase()) {
      var first = capturePage(document, curOff);
      if (first.items.length) { results = results.concat(first.items); pages++; tres = totalOf(document); }
    }
    var nextOff = results.length ? curOff + 24 : 0;
    while (results.length < TARGETN && pages < MAXPAGES) {
      say('"' + kw + '" page ' + (pages + 1) + " (" + results.length + " products so far)");
      var got = await loadPage(kw, nextOff);
      if (!got.items.length) break;
      if (!tres && got.tot) tres = got.tot;
      results = results.concat(got.items);
      pages++; nextOff += 24;
      await sleep(500);
    }
    var seen = {}, dd = [];
    for (var i = 0; i < results.length; i++) {
      var it = results[i], t = it.tcin;
      if (!t) continue;
      if (seen[t] === undefined) { seen[t] = dd.length; dd.push(it); }
      else { var ex = dd[seen[t]]; if (ex.sponsored && !it.sponsored) dd[seen[t]] = it; }
    }
    dd.sort(function (a, b) { return a.position - b.position; });
    var oc = 0;
    for (var j = 0; j < dd.length; j++) {
      if (dd[j].sponsored) dd[j].organicPosition = null;
      else { oc++; dd[j].organicPosition = oc; }
    }
    if (!dd.length) return null;
    return {
      snap: {
        keyword: kw,
        capturedAt: new Date().toISOString(),
        totalResults: tres ? tres.num : null,
        totalResultsText: tres ? tres.txt : null,
        results: dd
      },
      organic: oc
    };
  }

  async function deliver(snaps, autoClose) {
    var grand = 0, grandOrg = 0;
    snaps.forEach(function (s) { grand += s.snap.results.length; grandOrg += s.organic; });
    var list = snaps.map(function (s) { return s.snap; });
    var out = JSON.stringify(list.length === 1 ? list[0] : list);
    var okMsg = list.length + " keyword(s), " + grand + " products (" + grandOrg + " organic) captured.";

    var acked = false;
    if (window.opener && !window.opener.closed) {
      try {
        var onAck = function (ev) { if (ev && ev.data && ev.data.scoutAck === true) acked = true; };
        window.addEventListener("message", onAck);
        window.opener.postMessage({ scoutSnapshot: true, snaps: list }, "*");
        say(okMsg + " Sending to dashboard…");
        await sleep(1500);
        window.removeEventListener("message", onAck);
      } catch (e) {}
    }
    try { await navigator.clipboard.writeText(out); } catch (e) {}

    if (acked) {
      say(okMsg + " Imported into your dashboard." + (autoClose ? " Closing this tab…" : ""));
      if (autoClose) { await sleep(1400); try { window.close(); } catch (e) {} }
      else clearOverlay(6000);
    } else {
      say(okMsg + " Copied to clipboard — switch to the dashboard tab (or use Import snapshot).");
      clearOverlay(12000);
    }
  }

  async function waitForPageReady() {
    var t0 = Date.now();
    while (Date.now() - t0 < 20000) {
      try {
        var r = capturePage(document, 0);
        if (r.items.length) return true;
      } catch (e) {}
      await sleep(700);
    }
    return false;
  }

  var running = false;
  async function run(autoClose) {
    if (running) return;
    running = true;
    try {
      var kw = currentKeyword();
      if (!kw) { say("open a Target search results page first"); clearOverlay(5000); return; }
      say('capturing "' + kw + '"…');
      await waitForPageReady();
      var r = await captureKeyword(kw);
      if (!r) { say("no products found on this page"); clearOverlay(6000); return; }
      await deliver([r], autoClose);
    } catch (e) {
      say("error: " + ((e && e.message) || e));
      clearOverlay(8000);
    } finally {
      running = false;
    }
  }

  // Manual trigger: extension icon click.
  try {
    chrome.runtime.onMessage.addListener(function (msg) {
      if (msg && msg.scoutRun) run(false);
    });
  } catch (e) {}

  // Auto trigger: tab opened by the Scout dashboard.
  if (q.get("scout") === "auto" && currentKeyword()) {
    setTimeout(function () { run(true); }, 800);
  }
})();
